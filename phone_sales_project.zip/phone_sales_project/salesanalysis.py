import pandas as pd
import matplotlib.pyplot as plt

# Loading the iphone sales data in pandas dataframe
df = pd.read_csv("iphone_sales_project/iphone_sales_data.csv")

# ################### Milestone 1 ######################
# ########## Task 1 : Data Gathering and Cleaning #############
# # # top 5 rows
print(df.head())
# # # Checking the total number of rows and columns
print(f"Total number of rows and columns : {df.shape}")


# # # Checking and removing duplicates
# # # Checking for the duplicate value in the whole dataset
duplicate = df.duplicated().sum()
print(duplicate)
# # # # Checking duplicate for specific field
region_duplicate = df.duplicated(
    subset=["date", "region", "model"], keep="first")
print(region_duplicate)
df = df.drop_duplicates()
print(f"Total number of rows and columns : {df.shape}")


# # Checking non-null values in data
print(f"Total number of rows per field : \n{df.count(axis=0)}")
# # # Checking for missing values and handling them
print(f"Displaying count for field having null values : \n{df.isna().sum()}")

# # Filling up for the null values
null_columns = ["units_sold_millions", "avg_price_usd", "search_trend_index"]
for i in null_columns:
    df[i] = df[i].fillna(df[i].median())

print(
    f"Total number of rows per field after handling null values : \n{df.count(axis=0)}")
print(
    f"Displaying count for field having null values after filling missing values: \n{df.isna().sum()}")

# # # Capitalizing the field : Region
df["region"] = df["region"].str.strip().str.title()
print(df["region"])

# # Saving cleaned data in new csv file
df.to_csv("iphone_sales_project/iphone_salesdata_cleaned.csv", index=False)


########## Task 2 : Sales Trend Analysis ##############
df1 = pd.read_csv("iphone_sales_project/iphone_salesdata_cleaned.csv")
# Making sure date field is in date format
df1["date"] = pd.to_datetime(df1["date"])
# print(df1["date"])
# Global Sales Trend Line Plot
# Grouping the data to view month wise aggregation for two critical fields
df1_monthly = df1.groupby(df1["date"].dt.to_period("M")).agg(
    {"units_sold_millions": "sum", "revenue_usd_billions": "sum"}).reset_index()
# print(df1_monthly)
# # # Making sure date field after aggregation is in full timestamp which previously had the monthly data
df1_monthly["date"] = df1_monthly["date"].dt.to_timestamp()
# print(df1_monthly)

# # # Plotting the graph
plt.figure(figsize=(12, 6))
plt.plot(df1_monthly['date'], df1_monthly['units_sold_millions'],
         marker='o', label='Units Sold')
plt.plot(df1_monthly['date'], df1_monthly['revenue_usd_billions'],
         marker='s', label='Revenue (Billion USD)')
plt.title("Total Units Sold and Revenue Over Time")
plt.xlabel("Month")
plt.ylabel("Units / Revenue")
plt.legend()
plt.grid(True)
plt.show()

# Peak Sales Period -Monthly Averages
# Breaking down into month
df1["month"] = df1["date"].dt.month
# # # Calculating monthly mean average
monthly_avg = df1.groupby(df1["month"])["units_sold_millions"].mean()
# # print(monthly_avg)
plt.figure(figsize=(12, 6))
plt.bar(monthly_avg.index, monthly_avg.values)
plt.title("Average units sold millions per month")
plt.xlabel("Month")
plt.ylabel("Units sold million")
plt.xticks(range(1, 13))
plt.show()

# Grouping and aggregating by region and month
# print(df1)
region_average = df1.groupby(["region", "month"])[
    "units_sold_millions"].mean().unstack()
plt.figure(figsize=(12, 6))
plt.imshow(region_average, cmap='YlGnBu', aspect='auto')
plt.title("Aggregating by region and month")
plt.xlabel("Month")
plt.ylabel("Region")
plt.xticks(range(12), range(1, 13))
plt.yticks(range(len(region_average.index)), region_average.index)
plt.show()


############### Milestone 2 #######################
################### Task 1 :Business Strategy Recommendations ##################
print(f""" Business Strategy Recommendation :
From the data, November (month 11) shows the highest average sales (7.10M units) — this is likely due to holiday promotions (Black Friday) and pre-holiday buying.
To increase more sales what we can do is start marketing by October in anticipation of November sales.
Similarly , for the low sales period which is July (3.78M) and October (2.52M), we can provide promotional discounts or bundle offers during these months to maintain steady sales.
Also, when we aggregate by region and month we can see that Americas and Greater China has the stable sales, and therefore targeting the early launches and promotions for these segments can serve for faster expansion.
""")

################ Task 2 : Predictive Sales Modeling #################
# Taking the data of last 3 month ... We already have grouped the data month wise for the field : units_sold_millions and revenue_usd_billions
last_3 = df1_monthly.tail(3)
print(last_3)
average_3 = last_3["units_sold_millions"].mean()
print(average_3)
# Predicting the data for next 3 month based on the last 3 month
future_3 = pd.date_range(start=last_3["date"].max(
) + pd.DateOffset(months=1), periods=3, freq="M")
print(future_3)
# Assuming we have the same prediction for next 3 months
future_sales = [average_3] * 3
print(future_sales)
future_df = pd.DataFrame(
    {"date": future_3, "units_sold_millions": future_sales})
combined_df = pd.concat([last_3, future_df])
plt.figure(figsize=(12, 6))
plt.plot(df1_monthly['date'].tail(6), df1_monthly['units_sold_millions'].tail(
    6), marker='o', label='Past Sales', color='blue')
plt.plot(future_df['date'], future_df['units_sold_millions'], marker='s',
         linestyle='--', color='orange', label='Forecast (Next 3 Months)')
plt.title("iPhone Sales: Past 3 Months vs Next 3 Months Forecast")
plt.xlabel("Date")
plt.ylabel("Units Sold (Millions)")
plt.legend()
plt.grid(True)
plt.show()
